package com.ioc;

public interface UserDao {
    public void say();
}
