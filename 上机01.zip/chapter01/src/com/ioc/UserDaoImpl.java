package com.ioc;

public class UserDaoImpl implements UserDao{

    @Override
    public void say() {
        System.out.println("hello spring");
    }
}
