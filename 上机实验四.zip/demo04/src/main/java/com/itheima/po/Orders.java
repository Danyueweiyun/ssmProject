package com.itheima.po;

public class Orders {
	private Integer id;
	private Integer user_id;
	private String number;
	private String createTime;
	private String note;
	public Orders() {
		super();
	}
	public Orders(Integer id, Integer user_id, String number, String createTime, String note) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.number = number;
		this.createTime = createTime;
		this.note = note;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	@Override
	public String toString() {
		return "Orders [id=" + id + ", user_id=" + user_id + ", number=" + number + ", createTime=" + createTime
				+ ", note=" + note + "]";
	}
	
}
