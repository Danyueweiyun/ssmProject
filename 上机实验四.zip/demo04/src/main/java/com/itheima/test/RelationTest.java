package com.itheima.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.itheima.po.Orders;
import com.itheima.po.User;
import com.itheima.service.impl.UserServiceImpl;


public class RelationTest {

	@Test
	public void getBean() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		User user = (User) act.getBean("user");
		System.out.println(user);
	}
//	1.1 ����id���е����û���Ϣ�Ĳ�ѯ
	@Test
	public void getAUserByIdTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		User user = userServiceImpl.getAUserById(1);
		System.out.println(user);
	}
//	1.2 ���ݶ��idͬʱ��ѯ����û���Ϣ
	@Test
	public void getManyUsersByIdsTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		List<Integer> listid = new ArrayList<Integer>();
		listid.add(1);
		listid.add(10);
		listid.add(16);
		List<User> userlist = userServiceImpl.getManyUsersByIds(listid);
		System.out.println(userlist);
	}
//	1.3�����û�������ģ����ѯ
	@Test
	public void getManyUsersByConcatUsernameTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		User user = new User();
		user.setUsername("��");
		List<User> userlist = userServiceImpl.getManyUsersByConcatUsername(user);
		System.out.println(userlist);
	}
	
	@Test
//	2.1 ���user�û��ĸ��²���
	public void updateUserInfoTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		User user = new User();
		user.setId(10);
		user.setUsername("��san");
		user.setAddress("�����");
		int n = userServiceImpl.updateUserInfo(user);
		if(n <= 0) {
			System.out.println("����ʧ��");
		}else {
			System.out.println("�ɹ�");
		}
	}
	
	@Test
//	3.1 ����user�û���Ϣ
	public void  insertUserInfoTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		User user = new User();
		user.setUsername("��ɳ��");
		user.setBirthday("1961-11-25");
		user.setSex("��");
		user.setAddress("�����");
		int n = userServiceImpl.insertUserInfo(user);
		if(n <= 0) {
			System.out.println("����ʧ��");
		}else {
			System.out.println("�ɹ�");
		}
	}
	
	@Test
//	4.1 ���ݶ�����Ų�ѯ�û���Ϣ
	public void findUserInfoByOrderNumberTest() {
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		String number = "1000010";
		User user = userServiceImpl.findUserInfoByOrderNumber(number);
		System.out.println(user);
	}
	
	@Test
//	4.2 �����û�����ѯ�û��Ķ�����Ϣ
	public void findOrderInfoByUserNameTest(){
		ApplicationContext act = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserServiceImpl userServiceImpl = (UserServiceImpl) act.getBean("userServiceImpl");
		String username = "����";
		List<Orders> orders = userServiceImpl.findOrderInfoByUserName(username);
		System.out.println(orders);
	}
}
